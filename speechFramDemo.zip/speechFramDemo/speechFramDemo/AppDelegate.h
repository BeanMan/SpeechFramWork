//
//  AppDelegate.h
//  speechFramDemo
//
//  Created by bean on 2017/2/21.
//  Copyright © 2017年 com.xile. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

