//
//  main.m
//  speechFramDemo
//
//  Created by bean on 2017/2/21.
//  Copyright © 2017年 com.xile. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
