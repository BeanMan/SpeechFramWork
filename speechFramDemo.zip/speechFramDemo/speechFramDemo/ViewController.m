//
//  ViewController.m
//  bnbvn
//
//  Created by bean on 2017/2/21.
//  Copyright © 2017年 com.xile. All rights reserved.
//

/*
 -------------------------------------------
 -------------------------------------------
 -------------------------------------------
 -------------------------------------------
 ----------------第一种做法-------------------
 -------------------------------------------
 -------------------------------------------
 -------------------------------------------
 -------------------------------------------
 */
//#import "ViewController.h"
////#import <Foundation/Foundation.h>
////
////#import <Speech/SFSpeechRecognitionResult.h>
////#import <Speech/SFSpeechRecognitionRequest.h>
////#import <Speech/SFSpeechRecognitionTask.h>
////#import <Speech/SFSpeechRecognitionTaskHint.h>
////#import <Speech/SFSpeechRecognizer.h>
////#import <Speech/SFTranscriptionSegment.h>
////#import <Speech/SFTranscription.h>
//#import <Speech/Speech.h>
//
//@interface ViewController ()<SFSpeechRecognitionTaskDelegate>
//
//@property (nonatomic ,strong) SFSpeechRecognitionTask *recognitionTask;
//@property (nonatomic ,strong) SFSpeechRecognizer      *speechRecognizer;
//@property (nonatomic ,strong) UILabel                 *recognizerLabel;
//
//
//@end
//
//@implementation ViewController
//
//- (void)dealloc {
//    [self.recognitionTask cancel];
//    self.recognitionTask = nil;
//}
//
//- (void)viewDidLoad {
//    [super viewDidLoad];
//    // Do any additional setup after loading the view.
//    self.view.backgroundColor = [UIColor whiteColor];
//
//    //0.0获取权限
//    //0.1在info.plist里面配置
//    /*
//     typedef NS_ENUM(NSInteger, SFSpeechRecognizerAuthorizationStatus) {
//     SFSpeechRecognizerAuthorizationStatusNotDetermined,
//     SFSpeechRecognizerAuthorizationStatusDenied,
//     SFSpeechRecognizerAuthorizationStatusRestricted,
//     SFSpeechRecognizerAuthorizationStatusAuthorized,
//     };
//     */
//    [SFSpeechRecognizer requestAuthorization:^(SFSpeechRecognizerAuthorizationStatus status) {
//        switch (status) {
//            case SFSpeechRecognizerAuthorizationStatusNotDetermined:
//                NSLog(@"NotDetermined");
//                break;
//            case SFSpeechRecognizerAuthorizationStatusDenied:
//                NSLog(@"Denied");
//                break;
//            case SFSpeechRecognizerAuthorizationStatusRestricted:
//                NSLog(@"Restricted");
//                break;
//            case SFSpeechRecognizerAuthorizationStatusAuthorized:
//                NSLog(@"Authorized");
//                break;
//            default:
//                break;
//        }
//    }];
//
//    //1.创建SFSpeechRecognizer识别实例
//    self.speechRecognizer = [[SFSpeechRecognizer alloc] initWithLocale:[[NSLocale alloc] initWithLocaleIdentifier:@"zh_CN"]];//中文识别
//    //@"zh"在iOS9之后就不是简体中文了，而是TW繁体中文
//
////    [SFSpeechRecognizer supportedLocales];//根据手机设置的语言识别
////    for (NSLocale *lacal in [SFSpeechRecognizer supportedLocales].allObjects) {
////        NSLog(@"countryCode:%@  languageCode:%@ ", lacal.countryCode, lacal.languageCode);
////    }
//
//
//    //2.创建识别请求
//    SFSpeechURLRecognitionRequest *request = [[SFSpeechURLRecognitionRequest alloc] initWithURL:[NSURL fileURLWithPath:[[NSBundle mainBundle] pathForResource:@"1122334455.mp3" ofType:nil]]];
//
//    //3.开始识别任务
//    self.recognitionTask = [self recognitionTaskWithRequest1:request];
//}
//
//- (SFSpeechRecognitionTask *)recognitionTaskWithRequest0:(SFSpeechURLRecognitionRequest *)request{
//
//    return [self.speechRecognizer recognitionTaskWithRequest:request resultHandler:^(SFSpeechRecognitionResult * _Nullable result, NSError * _Nullable error) {
//        if (!error) {
//            NSLog(@"语音识别解析正确--%@", result.bestTranscription.formattedString);
//        }else {
//            NSLog(@"语音识别解析失败--%@", error);
//        }
//    }];
//}
//
//- (SFSpeechRecognitionTask *)recognitionTaskWithRequest1:(SFSpeechURLRecognitionRequest *)request{
//    return [self.speechRecognizer recognitionTaskWithRequest:request delegate:self];
//}
//
//- (void)didReceiveMemoryWarning {
//    [super didReceiveMemoryWarning];
//    // Dispose of any resources that can be recreated.
//}
//
//#pragma mark- SFSpeechRecognitionTaskDelegate
//
//// Called when the task first detects speech in the source audio
//- (void)speechRecognitionDidDetectSpeech:(SFSpeechRecognitionTask *)task
//{
//
//}
//
//// Called for all recognitions, including non-final hypothesis
//- (void)speechRecognitionTask:(SFSpeechRecognitionTask *)task didHypothesizeTranscription:(SFTranscription *)transcription {
//
//}
//
//// Called only for final recognitions of utterances. No more about the utterance will be reported
//- (void)speechRecognitionTask:(SFSpeechRecognitionTask *)task didFinishRecognition:(SFSpeechRecognitionResult *)recognitionResult {
//    NSDictionary *attributes = @{
//                                 NSFontAttributeName:[UIFont systemFontOfSize:18],
//                                 };
//
//    CGRect rect = [recognitionResult.bestTranscription.formattedString boundingRectWithSize:CGSizeMake(self.view.bounds.size.width - 100, CGFLOAT_MAX) options:NSStringDrawingUsesLineFragmentOrigin attributes:attributes context:nil];
//    self.recognizerLabel.text = recognitionResult.bestTranscription.formattedString;
//    self.recognizerLabel.frame = CGRectMake(50, 120, rect.size.width, rect.size.height);
//}
//
//// Called when the task is no longer accepting new audio but may be finishing final processing
//- (void)speechRecognitionTaskFinishedReadingAudio:(SFSpeechRecognitionTask *)task {
//
//}
//
//// Called when the task has been cancelled, either by client app, the user, or the system
//- (void)speechRecognitionTaskWasCancelled:(SFSpeechRecognitionTask *)task {
//
//}
//
//// Called when recognition of all requested utterances is finished.
//// If successfully is false, the error property of the task will contain error information
//- (void)speechRecognitionTask:(SFSpeechRecognitionTask *)task didFinishSuccessfully:(BOOL)successfully {
//    if (successfully) {
//        NSLog(@"全部解析完毕");
//    }
//}
//
//#pragma mark- getter
//
//- (UILabel *)recognizerLabel {
//    if (!_recognizerLabel) {
//        _recognizerLabel = [[UILabel alloc] initWithFrame:CGRectMake(50, 120, self.view.bounds.size.width - 100, 100)];
//        _recognizerLabel.numberOfLines = 0;
//        _recognizerLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleBody];
//        _recognizerLabel.adjustsFontForContentSizeCategory = YES;
//        _recognizerLabel.textColor = [UIColor orangeColor];
//        [self.view addSubview:_recognizerLabel];
//    }
//    return _recognizerLabel;
//}
//
//@end



#import "ViewController.h"
#import <Speech/Speech.h>
@interface ViewController ()<SFSpeechRecognizerDelegate>

@property (nonatomic, strong) AVAudioEngine *audioEngine;                           // 声音处理器
@property (nonatomic, strong) SFSpeechRecognizer *speechRecognizer;                 // 语音识别器
@property (nonatomic, strong) SFSpeechAudioBufferRecognitionRequest *speechRequest; // 语音请求对象
@property (nonatomic, strong) SFSpeechRecognitionTask *currentSpeechTask;           // 当前语音识别进程
@property (nonatomic, strong) UILabel *showLb;       // 用于展现的label
@property (nonatomic, strong) UIButton *startBtn;    // 启动按钮


@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    // 初始化
    self.audioEngine = [AVAudioEngine new];
    // 这里需要先设置一个AVAudioEngine和一个语音识别的请求对象SFSpeechAudioBufferRecognitionRequest
    self.speechRecognizer = [SFSpeechRecognizer new];
    self.startBtn.enabled = NO;
    
    [SFSpeechRecognizer requestAuthorization:^(SFSpeechRecognizerAuthorizationStatus status)
     {
         if (status != SFSpeechRecognizerAuthorizationStatusAuthorized)
         {
             // 如果状态不是已授权则return
             return;
         }
         
         // 初始化语音处理器的输入模式
         [self.audioEngine.inputNode installTapOnBus:0 bufferSize:1024 format:[self.audioEngine.inputNode outputFormatForBus:0] block:^(AVAudioPCMBuffer * _Nonnull buffer,AVAudioTime * _Nonnull when)
          {
              // 为语音识别请求对象添加一个AudioPCMBuffer，来获取声音数据
              [self.speechRequest appendAudioPCMBuffer:buffer];
          }];
         // 语音处理器准备就绪（会为一些audioEngine启动时所必须的资源开辟内存）
         [self.audioEngine prepare];
         
         self.startBtn.enabled = YES;
     }];
    
}
- (void)onStartBtnClicked
{
    if (self.currentSpeechTask.state == SFSpeechRecognitionTaskStateRunning)
    {   // 如果当前进程状态是进行中
        
        [self.startBtn setTitle:@"开始录制" forState:UIControlStateNormal];
        // 停止语音识别
        [self stopDictating];
    }
    else
    {   // 进程状态不在进行中
        [self.startBtn setTitle:@"停止录制" forState:UIControlStateNormal];
        self.showLb.text = @"等待";
        // 开启语音识别
        [self startDictating];
    }
}


/*
 所有的私有权限
 Privacy - Media Library Usage Description 使用媒体资源库
 Privacy - Calendars Usage Description 使用日历
 Privacy - Motion Usage Description 使用蓝牙
 Privacy - Camera Usage Description 使用相机
 Privacy - Health Update Usage Description 使用健康更新
 Privacy - Microphone Usage Description 使用麦克风
 Privacy - Bluetooth Peripheral Usage Description 使用蓝牙
 Privacy - Health Share Usage Description 使用健康分享
 Privacy - Reminders Usage Description 使用提醒事项
 Privacy - Location Usage Description 使用位置
 Privacy - Location Always Usage Description 始终访问位置
 Privacy - Photo Library Usage Description 访问相册
 Privacy - Speech Recognition Usage Description 使用语音识别
 Privacy - Location When In Use Usage Description 使用期间访问位置
 */
- (void)startDictating
{
    NSError *error;
    // 启动声音处理器
    [self.audioEngine startAndReturnError: &error];
    // 初始化
    self.speechRequest = [SFSpeechAudioBufferRecognitionRequest new];
    // 使用speechRequest请求进行识别
    self.currentSpeechTask =
    [self.speechRecognizer recognitionTaskWithRequest:self.speechRequest resultHandler:^(SFSpeechRecognitionResult * _Nullable result,NSError * _Nullable error)
     {
         // 识别结果，识别后的操作
         if (result == NULL) return;
         self.showLb.text = result.bestTranscription.formattedString;
     }];
}

- (void)stopDictating
{
    // 停止声音处理器，停止语音识别请求进程
    [self.audioEngine stop];
    [self.speechRequest endAudio];
}





#pragma mark- getter

- (UILabel *)showLb {
    if (!_showLb) {
        _showLb = [[UILabel alloc] initWithFrame:CGRectMake(50, 180, self.view.bounds.size.width - 100, 100)];
        _showLb.numberOfLines = 0;
        _showLb.font = [UIFont preferredFontForTextStyle:UIFontTextStyleBody];
        _showLb.text = @"等待中...";
        _showLb.adjustsFontForContentSizeCategory = YES;
        _showLb.textColor = [UIColor orangeColor];
        [self.view addSubview:_showLb];
    }
    return _showLb;
}

- (UIButton *)startBtn {
    if (!_startBtn) {
        _startBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        _startBtn.frame = CGRectMake(50, 80, 80, 80);
        [_startBtn addTarget:self action:@selector(onStartBtnClicked) forControlEvents:UIControlEventTouchUpInside];
        [_startBtn setBackgroundColor:[UIColor redColor]];
        [_startBtn setTitle:@"录音" forState:UIControlStateNormal];
        [_startBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [self.view addSubview:_startBtn];
        
    }
    return _startBtn;
}


@end
